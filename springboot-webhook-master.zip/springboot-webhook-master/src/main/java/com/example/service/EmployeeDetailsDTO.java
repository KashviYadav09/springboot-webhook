package com.example.service;

public class EmployeeDetailsDTO {
    private int empId;
    private String firstName;
    private String lastName;
    private String departmentName;
    private int youngerEmployeesCount;
	public int getEmpId() {
		// TODO Auto-generated method stub
		return 0;
	}

    // Constructor, Getters, Setters
}
