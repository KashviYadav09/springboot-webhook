package com.example.repository;

import com.example.repository.*;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Employee extends JpaRepository<Employee, Integer> {
}
