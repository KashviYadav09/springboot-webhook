package com.example.repository;

import org.springframework.data.jpa.repository.JpaRepository;

public interface Payment extends JpaRepository<Payment, Integer> {
}
