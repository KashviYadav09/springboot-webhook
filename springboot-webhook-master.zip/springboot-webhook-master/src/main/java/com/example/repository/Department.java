package com.example.repository;


import org.springframework.data.jpa.repository.JpaRepository;

public interface Department extends JpaRepository<Department, Integer> {
}
